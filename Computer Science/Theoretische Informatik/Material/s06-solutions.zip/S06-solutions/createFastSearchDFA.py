def createFastSearchDFA(alphabetStr, v):
    """
    Str -> Str -> DFA
    Create a DFA for the fast search for a pattern.  In a first step provide the alphabet, e.g. type abc for the alphabet {a,b,c}.  In a second step provide the pattern.
    """
    Sigma = {a for a in alphabetStr}
    delta = {}
    A = (Sigma, {i for i in range(0,len(v) + 1)},delta,0,{len(v)})
    # Define transitions for the first and last state and
    # Define transitions, each of which leads to the next higher state
    for a in Sigma:
        delta[len(v), a] = len(v)
        delta[0,a] = 0
    for i in range(0, len(v)):
        delta[i, v[i]] = i + 1
    # Define remaining transitions
    # search maximum suffix of the word read so far,
    # which is also the prefix of the search string
    for i in range(1, len(v)):
        for a in (Sigma - {v[i]}):		
            prefix = v[0:i]
            suffix = v[1:i] + a
            while prefix!=suffix:
                prefix = prefix[0:-1]
                suffix = suffix[1:]
            delta[i, a] = len(prefix)
    return A
